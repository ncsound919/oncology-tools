import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import DebateSummaryTakeawaysCard from '../DebateSummaryTakeawaysCard';
import { DebateSession } from '../../types';

describe('DebateSummaryTakeawaysCard Component Suite', () => {
  const mockSession: Partial<DebateSession> = {
    id: 'test-session-101',
    topic: 'Stochastic Plasticity vs Hierarchical Stemness in Oncology',
    rounds: [
      {
        index: 0,
        name: 'Opening Claims',
        timeWindowAllocatedSeconds: 180,
        timeWindowUsedSeconds: 90,
        statements: [
          {
            agentId: 'agent-1',
            agentName: 'Dr. Elena Rostova',
            role: 'Computational Oncologist',
            statementText: 'Single-cell chromatin accessibility reveals epigenetic plasticity.',
            updatedPosition: 0.85,
            updatedConfidence: 92,
            timing: {
              timestamp: 'T+00:30',
              elapsedSessionSeconds: 30,
              allocatedSeconds: 45,
              durationSeconds: 30,
              timeStatus: 'within_window',
            },
          },
        ],
      },
    ],
    judgeResult: {
      evaluationText: 'Epigenetic state switching under stress explains therapy escape.',
      winner: 'Reversible Plasticity Model',
      consensusScore: 85,
      candidateHypotheses: [
        {
          rank: 1,
          id: 'hyp-1',
          title: 'Reversible Epigenetic Plasticity Model',
          mechanism: 'HIF2A-mediated dedifferentiation under hypoxia',
          calibratedConfidence: 0.89,
          highestEvidenceTier: 1,
          noveltyScore: 85,
        },
      ],
      claimAuditTrail: [],
      minorityReports: [],
      keyArguments: [],
      dissent: 'In vivo validation still required.',
      openQuestions: [],
      quadLensScores: {
        scientific: 90,
        mathematical: 85,
        philosophical: 80,
        moral: 88,
      },
    },
  };

  it('returns null if there are no statements in the session', () => {
    const { container } = render(
      <DebateSummaryTakeawaysCard session={{ rounds: [] }} onOpenFullTranscript={vi.fn()} />
    );
    expect(container.firstChild).toBeNull();
  });

  it('renders executive summary header and consensus hypothesis title', () => {
    render(
      <DebateSummaryTakeawaysCard session={mockSession} onOpenFullTranscript={vi.fn()} />
    );

    expect(screen.getByText('Debate Executive Summary & Major Takeaways')).toBeTruthy();
    expect(screen.getByText('Reversible Plasticity Model')).toBeTruthy();
    expect(screen.getByText(/HIF2A-mediated dedifferentiation under hypoxia/)).toBeTruthy();
  });

  it('triggers onOpenFullTranscript when Open Full Report button is clicked', () => {
    const handleOpenModal = vi.fn();

    render(
      <DebateSummaryTakeawaysCard session={mockSession} onOpenFullTranscript={handleOpenModal} />
    );

    const openBtn = screen.getByTitle('Open comprehensive transcript dossier');
    fireEvent.click(openBtn);

    expect(handleOpenModal).toHaveBeenCalledTimes(1);
  });
});
